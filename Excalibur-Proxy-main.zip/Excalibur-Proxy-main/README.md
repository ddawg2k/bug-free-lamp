# Excalibur-Proxy
Effective Proxy For School<br/>

Homepage: https://studymath.xyz
